STUDIO PULSE — ONLINE-READY ROBLOX CCU DASHBOARD
Community: 934104263 | Refreshes every 10 seconds while open

DEPLOY TO RENDER (FREE TIER)
1. Make a new GitHub repository. Add index.html, favicon.svg, server.py, and render.yaml to the repository root. You can upload the files with GitHub's 'Add file > Upload files'.
2. Go to https://dashboard.render.com/ and create a New > Blueprint; connect the GitHub repository and confirm deployment. Alternatively, New > Web Service and set runtime to Python, start command to 'python server.py', and choose Free.
3. Render provides a public https://YOUR-NAME.onrender.com URL. The first load after inactivity may take a minute.

LOCAL WINDOWS
Double-click START.bat (Python 3 required), then open http://localhost:8765.

NOTES
- 10-second refresh runs while browser dashboard is open, not as a permanent background tracker.
- Roblox API may itself cache CCU figures.
- Graph history is browser-local, not permanently stored server-side.
- Render Free services sleep after approximately 15 minutes without incoming traffic.
- Your dashboard will be publicly accessible to anyone who knows the URL. No login is included.
